
cauzality_path<<-"./../.."

loud<-function() {

  source(sprintf('%s%s',cauzality_path,"/trunk/bayeslingam/loadbayeslingam.R"))
  loadbayeslingam()
}