# Copyright (c) 2010 - 2013  Jonas Peters  [peters@stat.math.ethz.ch]
# All rights reserved.  See the file COPYING for license terms. 

library(pcalg) 
source("../inferDAG/pcWrap.R")
source("../inferDAG/cpcWrap.R")

