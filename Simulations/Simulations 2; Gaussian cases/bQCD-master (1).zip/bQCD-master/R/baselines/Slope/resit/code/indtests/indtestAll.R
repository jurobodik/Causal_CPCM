indtestAll <- function(f,x,y,alpha,pars = list())
{
    result <- f(x,y,alpha,pars)
}

indtestMutualAll <- function(f,x,alpha,pars = list())
{
    result <- f(x,alpha,pars)
}
