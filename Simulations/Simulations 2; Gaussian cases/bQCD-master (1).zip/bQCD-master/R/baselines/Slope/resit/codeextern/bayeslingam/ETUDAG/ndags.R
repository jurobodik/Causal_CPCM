#returns the number of dags with p nodes

ndags<-function( p ) {
  npdags(p)
}