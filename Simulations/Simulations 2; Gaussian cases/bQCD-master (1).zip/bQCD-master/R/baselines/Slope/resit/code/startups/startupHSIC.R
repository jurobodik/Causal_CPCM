# Copyright (c) 2010 - 2013  Jonas Peters  [peters@stat.math.ethz.ch]
# All rights reserved.  See the file COPYING for license terms. 

source("../indtests/indtestAll.R")
source("../indtests/indtestHsicPairwise.R")
source("../indtests/indtestHsic.R")
source("../indtests/indtestMutualBonferroni.R")
source("../indtests/indtestMutualHsic.R")
#source("../indtests/indtestPcor.R")
library(kernlab)
