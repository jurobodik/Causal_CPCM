x<-rnorm(400,1)
y<-rnorm(400,1)
T<-indtestHsic(x,y)


x<-rnorm(400,1)
y<-0.5*x+rnorm(400,1)
T<-indtestHsic(x,y)



